DataTables Plugins
==================

Contributions are very welcome to this repo. Please create a pull request and/or post in the [forum](https://datatables.net/forums) to share it with us.

In the case of i18n Plugins, we ask that you don't create a pull request and instead make use of the [management system](https://datatables.net/plug-ins/i18n/) that we have in place for this on our website.
